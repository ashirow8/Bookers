Rails.application.routes.draw do
  
  resources :blogs
  root to:'homes#new'
  resources :books 
  #resources :books を使うことで５から１０行目の過程をまとめられる
  
  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html
end
